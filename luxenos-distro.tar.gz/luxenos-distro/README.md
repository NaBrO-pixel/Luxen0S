# LuxenOS

A free, open-source Linux desktop for x86_64 laptops that runs real Android
apps natively, distributed as a single install disc — boot it and you're in
the installer, not a demo desktop.

## What this is (and isn't)

LuxenOS is a **Debian remix**, built with `live-build`: Debian 13 "Trixie"
underneath, with a curated Sway/Wayland desktop, Waydroid for Android apps,
and Calamares for installation, all assembled into one image. It is not a
kernel or userland written from zero — no serious general-purpose desktop OS
is, realistically, without a multi-year team effort. What *is* built here,
specifically for this project: the desktop environment configuration, the
Android integration and its first-boot setup flow, the installer branding
and boot behavior, and the hardening/theming layered on top of Debian.

The ISO this repo builds boots straight into the graphical installer
(Calamares), not a live desktop session — see
["Why a non-live ISO"](#why-a-non-live-iso) below for how that's done on top
of a tool (`live-build`) that's normally only used for live images.

## Core functions

### Android app compatibility
[Waydroid](https://waydroid.org/) runs a real Android container alongside
your Linux desktop; Android apps appear as regular windows you can resize,
snap, and switch between like anything else. Set up by
`config/hooks/live/0100-install-waydroid.hook.chroot`:
- Downloads and configures the Waydroid repo/package at build time.
- Ships Aurora Store (an open-source Play Store frontend — no Google account
  needed) pre-downloaded and checksum-verified, so it's ready to install
  from first boot.
- Creates a one-shot systemd service that initializes the Android image on
  the *installed* system's first real boot.
- `lapdroid-setup-android` (installed to `/usr/local/bin`) walks through
  Aurora Store installation and, optionally, official Google Play Store
  certification for apps that require a Google account.

### The desktop
Sway (tiling Wayland compositor) + Waybar, configured under
`config/includes.chroot/etc/skel/.config/`, so every new user account gets
it by default. Includes screenshot/annotation (`grim`/`slurp`/`swappy`), a
power-profile switcher tied to `tlp`, GTK theming via `nwg-look`, and a
consistent color palette across Sway/Waybar/wofi/GRUB/Plymouth.

### Installation
Calamares, with LuxenOS branding
(`config/includes.chroot/etc/calamares/branding/luxenos/`) and support for
full-disk LUKS encryption. See below for how the boot flow works.

### Hardening
AppArmor with real profile packages (not just the empty service), UFW
default-deny-incoming, sysctl hardening
(`config/includes.chroot/etc/sysctl.d/99-luxenos.conf`), and
`unattended-upgrades` enabled on the installed system.

## Why a non-live ISO

`live-build` only knows how to build *live* images — bootable filesystems
you can run without installing. A truly different technology
(`debian-installer`, the tool behind Debian's own netinst ISO) is what
produces install-only media from scratch, and rewriting onto that toolchain
is out of scope here.

Instead, this repo gets the same practical result — boot the disc, land in
the installer, not a demo desktop — by configuring the live *session itself*
to skip the desktop and launch straight into Calamares
(`config/hooks/live/0150-installer-kiosk.hook.chroot`, using a minimal
autologin Sway session with nothing but Calamares in it). Once you finish
installing, `config/includes.chroot/etc/calamares/modules/removefiles.conf`
strips those kiosk-only files from your new disk install, so what you
actually boot into afterward is the full Sway/Waybar/Waydroid desktop, not a
stripped installer environment. This is functionally a dedicated installer
disc, even though `live-build` is what builds it.

## How it compares to macOS and Windows

Genuine differentiators, not benchmark claims (we haven't run head-to-head
performance numbers, and you should be skeptical of any distro that claims
to "beat" a mainstream OS without receipts):

- **Native Android apps.** Neither macOS nor Windows runs Android apps
  without a third-party emulator layer; LuxenOS has Waydroid configured out
  of the box.
- **Hardware longevity.** Built and tested against a Dell Latitude E6440 —
  older than current Windows 11's official hardware requirements, and past
  the point macOS supports it at all. LuxenOS keeps that hardware on an
  actively updated desktop.
- **Ownership.** GPLv3-licensed, no telemetry you didn't opt into, no
  subscription required to use your own machine, fully auditable and
  forkable.

## Target

- Hardware: Dell Latitude E6440 and similar amd64 laptops
- Base: Debian 13 "Trixie"
- Desktop (post-install): Sway + Waybar
- Android runtime: Waydroid, GAPPS or VANILLA image, Aurora Store fallback
- Boot mode: UEFI via `grub-efi-amd64`

## Requirements to build

```sh
sudo apt update
sudo apt install live-build curl ripgrep
```

## Environment variables

Required by `config/hooks/live/0100-install-waydroid.hook.chroot`:

| Variable | Purpose | Notes |
| --- | --- | --- |
| `WAYDROID_VERSION` | Version string, logged only | Informational |
| `WAYDROID_IMAGE_TYPE` | `GAPPS` or `VANILLA` | Required; build fails on any other value |
| `WAYDROID_REPO_URL` | URL of the Waydroid repo-setup script | Required |
| `WAYDROID_INSTALL_SCRIPT` | Local path to save that script to | Required |
| `AURORA_STORE_URL` | URL to download the Aurora Store APK from | Required to bundle Aurora Store |
| `AURORA_STORE_DIR` | Local directory for the downloaded APK | Required to bundle Aurora Store |
| `AURORA_STORE_SHA256` | Expected SHA-256 of the APK | **Required for release builds** |
| `LUXENOS_ALLOW_UNPINNED_DOWNLOADS` | `1` to build without `AURORA_STORE_SHA256` | Dev builds only |
| `DOWNLOAD_RETRIES` | Retry count for network downloads | Required |
| `CURL_TIMEOUT` | Per-attempt curl timeout (seconds) | Required |

Checksum verification is fail-closed: without `AURORA_STORE_SHA256` (and
without `LUXENOS_ALLOW_UNPINNED_DOWNLOADS=1`), the build stops rather than
shipping an unverified APK.

## Build steps

```sh
sudo lb clean --purge
sudo lb config
sudo lb build
```

Produces `live-image-amd64.hybrid.iso`. Booting it goes straight to
Calamares. A full build can take 30–90 minutes.

## Testing with QEMU

```sh
sudo apt install qemu-system-x86 qemu-kvm
qemu-system-x86_64 -m 4096 -enable-kvm -cdrom live-image-amd64.hybrid.iso
```

## Flashing to USB

```sh
lsblk
sudo dd if=live-image-amd64.hybrid.iso of=/dev/sdX bs=4M status=progress conv=fsync
```

Replace `/dev/sdX` with the whole USB device, not a partition.

## After installing

First boot needs internet access so Waydroid can download and initialize
its Android image, then:

```sh
lapdroid-setup-android
```

## Key bindings (installed desktop)

| Shortcut | Action |
| --- | --- |
| Super+Return | Terminal (Foot) |
| Super+D | App launcher (wofi) |
| Super+A | Open Waydroid / Android UI |
| Super+L | Lock screen |
| Super+Shift+E | Exit / logout |
| Super+F | Fullscreen |
| Super+1-4 | Switch workspaces |
| Print | Screenshot to clipboard + `~/Pictures` |
| Super+Shift+S | Select region + annotate (swappy) |
| Super+P | Cycle power profile |
| Super+Shift+H | Run the health check |

## Troubleshooting

**Boots to a black screen/terminal instead of Calamares.**
The kiosk session execs `sway` from `.bash_profile` on tty1 only. Log in and
run `sway` manually, or check `journalctl -b` for a crash.

**The installed system booted back into Calamares.**
The `removefiles` cleanup step didn't run. Check the Calamares install log
(`/var/log/calamares` on the live session before reboot). Manual fix: chroot
into the install and remove `/etc/luxenos-installer` and
`/etc/systemd/system/getty@tty1.service.d/luxenos-autologin.conf`.

**`waydroid-first-init.service` failed on first real boot.**
```sh
systemctl status waydroid-first-init.service
journalctl -u waydroid-first-init.service
sudo systemctl restart waydroid-first-init.service
```
Usually a flaky network during the Android image download.

**Waydroid never starts.**
Check CPU virtualization is available: `grep -E 'vmx|svm' /proc/cpuinfo`
(also checked by `luxenos-health-check`). Enable virtualization/nested
virtualization in BIOS/hypervisor settings if it's missing.

## Project layout

```text
auto/config                                          live-build target settings
config/package-lists/base.list.chroot                 Core system/services
config/package-lists/desktop.list.chroot               Sway, Waybar, Firefox, desktop apps
config/package-lists/android.list.chroot                Waydroid hook prerequisites
config/package-lists/installer.list.chroot              Calamares + partitioning tools
config/package-lists/security.list.chroot                AppArmor, tlp, ufw, unattended-upgrades
config/hooks/live/0100-install-waydroid.hook.chroot    Waydroid + Aurora Store (core Android feature)
config/hooks/live/0150-installer-kiosk.hook.chroot     Non-live boot: straight into Calamares
config/hooks/live/0200-configure-premium-defaults.hook.chroot
                                                       Services, firewall, Plymouth/GRUB theming
config/includes.chroot/etc/luxenos-installer/          Kiosk-only Sway config (live session)
config/includes.chroot/etc/calamares/                  Installer branding, settings, cleanup job
config/includes.chroot/etc/skel/.config/                Installed system's default desktop
.github/workflows/validate.yml                         CI: tree validation + lb config dry run
tools/validate-release-tree                            Local/CI structural + syntax checks
CONTRIBUTING.md                                        Where things go, how to test changes
```

## License

GPLv3 — see [LICENSE](LICENSE).
